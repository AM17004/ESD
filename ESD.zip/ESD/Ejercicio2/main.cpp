#include <iostream>

int main() {
    int n;
    int cs;
    printf("Inserte tamaño del vector \n");
    scanf("%d", &n);
    int vector1[n];
    printf("Inserte datos del vector \n");
    for (int i=0; i<n; ++i){
        scanf("%i", &vector1[n]);
    }
    printf("Inserte la posicion que desea borrar \n");
    scanf("%i", &cs);
    int borrado;
    if(cs>n){
        std::cout<<"Esta posicion no existe"<<std::endl;
        for(int h=0; h<n; ++h){
            std::cout<<"El valor en la posicion"<< h <<"Del vector es:"<< vector1[h] <<std::endl;
        }

    }else{
        borrado=vector1[cs];
        for (int h=0; h<n; ++h){
            if(h==cs){
                while(h<n){
                    vector1[h]= vector1[h+1];
                    h++;
                } break;

            }
        }
        n=n-1;
        std::cout<<"Resultado"<< std::endl;
        for(int h=0; h<n; ++h){
            std::cout<<"El valor en la posicion"<< h <<"Del vector es:"<< vector1[h] <<std::endl;
        }
    }
    return 0;
}