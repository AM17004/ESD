#include <iostream>

int main() {
    int num, num2;
    printf( "Inserte la dimension del vector \n");
    scanf("%d", &num);
    int vector[num];
    printf("Inserte datos del vector \n");
    for (int i=0; i < num; ++i) {
        scanf("%i", &vector[i]);
    }

    printf("Inserte la dimension del vector que desea copiar\n");
    scanf("%d", &num2);
    int vector1[num2];
    printf("Inseerte los datos del vector a copiar");
    for(int i =0; i<num2; ++i){
        scanf("%i", &vector1[i]);
    }
    int re= num + num2;
    int vector2[re];
    for(int h=0; h<num; h++){
        vector2[h] = vector[h];
    }
    for(int h= num; h<re; h++){
        vector2[h]= vector1[h-num];
    }
    std:: cout << "Resultado del vector cpiado" << std::endl;
    for(int h=0; h<re; h++){
        std::cout<<vector2[h]<<std::endl;
    }

    return 0;
}