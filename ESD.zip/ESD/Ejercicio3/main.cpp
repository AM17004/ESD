#include <iostream>
#include<math.h>

int main() {
  int n;
  printf("Ingrese el tamaño del vector \n");
  scanf("%i", &n);
  double vector[n];
  double suma1=0;
  double suma2=0;
  double media, desviacion, varianza;

  for (int i=0; i<n; ++i){
      printf("Ingrese el numero[%i%s", i+1,"]: ");
      scanf("%lf", &vector[i]);
      suma1= suma1+vector[i];
  }
  media= suma1/n;

  for(int h=0; h<n; ++h) {
      suma2 = suma2 + pow((vector[h] - media), 2);
  }
      varianza=suma2/n;
      desviacion=sqrt(varianza);
      printf("\nLos datos son:\n");
      for(int x=0; x<n; ++x){
          printf("\n[%1f%s", vector[x],"]"".");

      }
      printf("\n");
      printf("\n La media es: %lf", media);
      printf("\n");
      printf("\n La varinza es: %lf", varianza);
      printf("\n");
      printf("\n La desviacion tipica es: %lf", desviacion);
      printf("\n");


    return 0;
}